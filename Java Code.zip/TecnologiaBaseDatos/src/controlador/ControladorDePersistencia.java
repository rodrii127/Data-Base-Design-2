package controlador;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.Query;
import clases.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


public class ControladorDePersistencia {    
    //Es "final" porque únicamente adquiere este valor en toda la ejecución del progama.
    //Es "static" porque posee este valor para todas las instancias de esta clase.
    //SessionFactory:  Esta clase contiene métodos para leer, guardar o borrar entidades sobre la base de datos.
    private static final SessionFactory sessionfactory = buildSessionFactory();
    
    private static SessionFactory buildSessionFactory() {

            try {
                Configuration configuration = new Configuration();
                configuration.configure("hibernate.cfg.xml");
                ServiceRegistry serviceregistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();                    
                SessionFactory sessionfactory = configuration.buildSessionFactory(serviceregistry);
                return sessionfactory;
            } catch (Throwable e) {
                System.out.println("La creación de Session Factory a fallado "+e) ;
                throw new ExceptionInInitializerError();
            }        
    }

    public static SessionFactory getSessionfactory() {
            return sessionfactory;
    }

    
    public boolean persistirInstancia(Object instancia){
	boolean resultado = false;
                
        Session session = getSessionfactory().getCurrentSession();
        
        //Para trabajar con una base de datos usamos las transacciones.
        Transaction t = session.getTransaction();
        t.begin();
	try {
            
            session.saveOrUpdate(instancia);
            
            /*
            * Se comprueba que se haya persistido la instancia.
            */
            resultado = session.contains(instancia);

	} catch (Exception e) {
            System.out.println("No se pudo guardar la instancia "+e);
	}
        t.commit();

        return resultado;
    }
    
    public boolean eliminarInstancia(Object instancia){
		boolean resultado = false;

                Session session = getSessionfactory().getCurrentSession();
                Transaction t = session.getTransaction();
                t.begin();
                try {
                    
                    session.delete(instancia);
                    resultado = true;
                    
		} catch (Exception e) {
                    System.out.println("No se pudo eliminar la instancia"+e);
                }
                t.commit();
		return resultado;
    }
    
    
    public boolean actualizarInstancias(){
        boolean resultado = false;

        Session session = getSessionfactory().getCurrentSession();
        Transaction t = session.getTransaction();
        
	try {
		t.begin();
		session.flush();
		t.commit();
                resultado = true;
	} catch (Exception e) {
            System.out.println("No se pudo actualizar las instancias"+e);
        }

        return resultado;
    }
    
    public boolean contieneInstancia(Object xxx){
        
        boolean resultado = false;
                
        Session session = getSessionfactory().getCurrentSession();
        
        Transaction t = session.getTransaction();
        t.begin();
	try {
            resultado = session.contains(xxx);
            t.commit();
        } catch (Exception e) {
            System.out.println("No se pudo guardar la instancia "+e);
	}
        t.commit();
        return resultado;
        
    }
    
    public List<Usuario> cargarUsuarios(){
                String textoConsulta = "SELECT c FROM Usuario c";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<Usuario> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    public List<Delegacion> cargarDelegaciones(){
                String textoConsulta = "SELECT d FROM Delegacion d";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<Delegacion> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    public List<Contribuyente> cargarContribuyentes(){
                String textoConsulta = "SELECT c FROM Contribuyente c";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<Contribuyente> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    
    public List<Fisico> cargarFisico(){
                String textoConsulta = "SELECT f FROM Fisico f";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<Fisico> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    
    public List<Juridico> cargarJuridicos(){
                String textoConsulta = "SELECT j FROM Juridico j";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<Juridico> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
}