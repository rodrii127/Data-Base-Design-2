package controlador;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class probando {
   
    public probando(){
        iniciarConexion();
        
    }
    
      private Connection c = null;
      private Statement stmt = null;
      
      
      public void iniciarConexion(){
         try {
              Class.forName("org.postgresql.Driver");
              c = DriverManager
                      .getConnection("jdbc:postgresql://localhost:5432/tpfinal",
                              "rodrigo", "1234");
          } catch (Exception e) {
              e.printStackTrace();
              System.err.println(e.getClass().getName() + ": " + e.getMessage());
              System.exit(0);
          }
          System.out.println("Opened database successfully");
      }
      
      
      
      public void probandoSelect(String anio){
        try {
            this.iniciarConexion();
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("select impuesto.id_contrib as contribuyente, extract(year from fecha_pago) as fecha, "
                    + " sum(monto_impue) as total from impuesto "
                    + " where extract(year from fecha_pago) = " + anio
                    + " group by extract(year from fecha_pago), impuesto.id_contrib;");
            
            while (rs.next()) {
                String contribuyente = rs.getString("contribuyente");
                String fecha = rs.getString("fecha");
                String total = rs.getString("total");
                System.out.println(contribuyente + fecha + total);
            }
            
            
            rs.close();
            stmt.close();
            c.close();
            
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Operation done successfully");
    }
          
      
      
      public void probandoInsert(){
          try {
              this.iniciarConexion();
             c.setAutoCommit(false);
            stmt = c.createStatement();
            
            String usuario = "migue";
            String pass = "saleS";
            
            String sql = "INSERT INTO usuario (usuario, pass) "
                    + "VALUES ('"+ usuario + "', '" + pass + "');";
            stmt.executeUpdate(sql);
            stmt.close();
            c.commit();
            c.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Records created successfully");

    }
      
      
      
      
}