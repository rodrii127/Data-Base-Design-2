package controlador;

import clases.*;
import java.util.*;

public class ControladorPrincipal {
    
    private ControladorDePersistencia persistencia;
    
    public ControladorPrincipal(ControladorDePersistencia persis){
        this.persistencia = persis;
    }
    
    public boolean realizarLogin(String user, String pass){
        
        List<Usuario> misUsuarios = persistencia.cargarUsuarios();
        for (Usuario miUsuario : misUsuarios) {
            if(miUsuario.getUsuario().equals(user) && miUsuario.getPass().equals(pass)){
                return true;
            }
        }
        return false;
    }
    
    public List<Delegacion> traerDelegaciones(){
        
        List<Delegacion> list = persistencia.cargarDelegaciones();
        
        return list;
    }
    
    public List<Contribuyente> traerContribuyentes(){
        
        List<Contribuyente> list = persistencia.cargarContribuyentes();
        
        return list;
    }
    
    
    public List<Fisico> traerFisico(){
        
        List<Fisico> list = persistencia.cargarFisico();
        
        return list;
    }
    
    
    public List<Juridico> traerJuridicos(){
        
        List<Juridico> list = persistencia.cargarJuridicos();
        
        return list;
    }
    
    
    
    public void InsertarContribuyente(Contribuyente contrib, Fisico fisico, Juridico juridico){
        
        List<Contribuyente> list = persistencia.cargarContribuyentes();
        
        int idContrib = (list.get(list.size() -1 ).getIdContrib()) +1;
        
        if(juridico.getRazonSocial() != null){
            juridico.setIdContrib(idContrib);
            persistencia.persistirInstancia(juridico);
        }else{
            fisico.setIdContrib(idContrib);
            persistencia.persistirInstancia(fisico);
        }
        
        contrib.setIdContrib(idContrib);
        
        persistencia.persistirInstancia(contrib);
        
    }
    
    
    public Contribuyente buscarContribuyente(int numero , String tipoContribuyente, int id_contribuyente){
        List<Contribuyente> listaContrib = persistencia.cargarContribuyentes();
        List<Fisico> listaFisicos = persistencia.cargarFisico();
        List<Juridico> listaJuridicos = persistencia.cargarJuridicos();
        
        Contribuyente contribuyente = new Contribuyente(0);
        Fisico fisico = new Fisico(0);
        Juridico juridico = new Juridico(0);
        
        boolean prueba = false;
        
        if (numero != 0) {
            prueba=true;
            if (tipoContribuyente.equals("FISICO")) {
                for (Fisico fisic : listaFisicos) {
                    if (fisic.getDni() == numero) {
                        fisico = fisic;
                        id_contribuyente = fisic.getIdContrib();
                    }
                }
            } else {
                if (tipoContribuyente.equals("JURIDICO")) {
                    for (Juridico jurid : listaJuridicos) {
                        if (jurid.getCuit() == numero) {
                            juridico = jurid;
                            id_contribuyente = jurid.getIdContrib();
                        }
                    }
                }
            }
        }else{
            for (Contribuyente contrib : listaContrib) {
                if(contrib.getIdContrib() == id_contribuyente){
                    contribuyente = contrib;
                }
            }
            if (tipoContribuyente.equals("FISICO")) {
                for (Fisico fisic : listaFisicos) {
                    if (fisic.getDni() == numero) {
                        fisico = fisic;
                    }
                }
            } else {
                if (tipoContribuyente.equals("JURIDICO")) {
                    for (Juridico jurid : listaJuridicos) {
                        if (jurid.getCuit() == numero) {
                            juridico = jurid;
                        }
                    }
                }
            }
        }
        
        if(prueba){
            for (Contribuyente contrib : listaContrib) {
                if(contrib.getIdContrib() == id_contribuyente){
                    contribuyente = contrib;
                }
            }
        }
        
        return contribuyente;
    }
    
    public boolean modificarContribuyente(Contribuyente contribuyente, String tipoContrib, Fisico fisico, 
                                                                        Juridico jurid, Delegacion delegacion){
        
        List<Contribuyente> misContrib = persistencia.cargarContribuyentes();
        
        for (Contribuyente contribuyente1 : misContrib) {
            if(contribuyente1.getIdContrib() == contribuyente.getIdContrib()){
                contribuyente1.setDelegacion(contribuyente.getDelegacion());
                contribuyente1.setTipoCategoria(contribuyente.getTipoCategoria());
                contribuyente1.setDelegacion(delegacion);
                System.out.println(delegacion.getCiudad());
                if(tipoContrib.equals("FISICO")){
                    for (Fisico fisico1 : persistencia.cargarFisico()) {
                        if(fisico1.getIdContrib() == fisico.getIdContrib()){
                            fisico1.setDni(fisico.getDni());
                            fisico1.setNombre(fisico.getNombre());
                            persistencia.persistirInstancia(fisico1);
                        }
                    }
                }else{
                    for (Juridico juridico1 : persistencia.cargarJuridicos()) {
                        if(juridico1.getIdContrib() == jurid.getIdContrib()){
                            juridico1.setCuit(jurid.getCuit());
                            juridico1.setRazonSocial(jurid.getRazonSocial());
                            persistencia.persistirInstancia(juridico1);
                        }
                    }
                }
                persistencia.persistirInstancia(contribuyente1);
                
                return true;
            }
        }
        
        return false;
    }
    
    
}
