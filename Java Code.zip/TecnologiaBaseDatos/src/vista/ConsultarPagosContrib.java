package vista;

import controlador.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConsultarPagosContrib extends javax.swing.JFrame {

    private probando p;
    private Connection c = null;
    private Statement stmt = null;
    private Statement stmt2 = null;

    public ConsultarPagosContrib(probando pr) {
        initComponents();
        setVisible(true);
        setTitle("Consultar Pagos de los No morosos");
        setLocationRelativeTo(null);
        this.p = pr;
    }

    public void cargarTabla(String anio) {

        int ind = 0, ind2 = 0;

        try {
            this.iniciarConexion();
            stmt = c.createStatement();
            stmt2 = c.createStatement();

            //resolver en una sola consulta
            ResultSet rs = stmt.executeQuery("select impuesto.id_contrib as contribuyente, "
                    + "extract(year from fecha_pago) as fecha, sum(monto_impue) as total from impuesto "
                    + "where extract(year from fecha_pago) = " + anio + "and (fecha_venci > fecha_pago) "
                    + "and extract(year from fecha_pago) > 1980"
                    + "group by extract(year from fecha_pago), impuesto.id_contrib;");

            ResultSet rs2 = stmt2.executeQuery("select id_contrib as contrib, sum(monto_impue) as total "
                                              + "from impuesto where extract (year from fecha_pago) = " + anio
                    + "group by id_contrib;");

            String[][] matriz = new String[15][3];
            String contribuyente = "ERROR";
            String fecha = "ERROR";
            String total = "ERROR";
            String[][] matrizFiltrado = new String[15][2];

            while (rs2.next()) {
                matrizFiltrado[ind2][0] = rs2.getString("contrib");
                matrizFiltrado[ind2][1] = rs2.getString("total");
                ind2++;
            }
            
            ind2 = 0;

            while (rs.next()) {
                for (int i = 0; i < matrizFiltrado.length; i++) {
                    if (rs.getString("contribuyente").equals(matrizFiltrado[i][0])
                            && rs.getString("total").equals(matrizFiltrado[i][1])) {
                        contribuyente = rs.getString("contribuyente");
                        fecha = rs.getString("fecha");
                        total = rs.getString("total");
                        matriz[ind][0] = contribuyente;
                        matriz[ind][1] = fecha;
                        matriz[ind][2] = total;
                        ind++;
                    }
                }
            }

            rs.close();
            rs2.close();
            stmt.close();
            stmt2.close();
            c.close();

            jTable1.setModel(new javax.swing.table.DefaultTableModel(
                    matriz,
                    new String[]{
                        "CONTRIBUYENTE", "AÑO", "MONTO"
                    }
            ));

        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }

    }

    public void iniciarConexion() {
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection("jdbc:postgresql://localhost:5432/tpfinal",
                            "rodrigo", "1234");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Opened database successfully");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        Cuadro = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Ingresar Año:");

        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Cuadro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CuadroActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "CONTRIBUYENTE", "AÑO", "MONTO"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(Cuadro, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(189, 189, 189)
                        .addComponent(jButton1))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Cuadro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CuadroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CuadroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CuadroActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String año;
        año = Cuadro.getText().toString();
        System.out.println(año);
        cargarTabla(año);
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Cuadro;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
