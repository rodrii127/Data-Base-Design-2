package vista;

import clases.Contribuyente;
import clases.*;
import controlador.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class BuscarContribuyente extends javax.swing.JFrame {

    ControladorPrincipal miControlador;
    Contribuyente miContribuyente = new Contribuyente(0);
    Fisico fisico = new Fisico(0);
    Juridico juridico = new Juridico(0);
    Delegacion delegacion = new Delegacion(0);
    
    public BuscarContribuyente(ControladorPrincipal miControlador) {
        this.miControlador = miControlador;
        setTitle("Buscar Contribuyente");
        setLocationRelativeTo(null);
        initComponents();
        cargarComboBox();
        jButton3.setEnabled(false);
    }

    public void cargarComboBox(){
        jComboBox1.addItem("");
        jComboBox1.addItem("FISICO");
        jComboBox1.addItem("JURIDICO");
    }
    
    
    public void cargarTabla(int numero, String tipo){
        String matriz[][] = new String[1][5];
        int dni_cuit = 0;
        String nombre = "";
        String ciudad = "";
        
        
        if (tipo.equals("JURIDICO")) {
            for (Juridico jurid : miControlador.traerJuridicos()) {
                if (miContribuyente.getIdContrib() == jurid.getIdContrib()) {
                    numero = jurid.getCuit();
                    nombre = jurid.getRazonSocial();
                    juridico = jurid;
                }
            }
        } else {
            for (Fisico fisic : miControlador.traerFisico()) {
                if (miContribuyente.getIdContrib() == fisic.getIdContrib()) {
                    numero = fisic.getDni();
                    nombre = fisic.getNombre();
                    fisico = fisic;
                }
            }
        }
        
        
        if (miContribuyente.getIdContrib() != 0) {
            for (Delegacion deleg : miControlador.traerDelegaciones()) {
                if (deleg.getIdDeleg() == miContribuyente.getDelegacion().getIdDeleg()) {
                    ciudad = deleg.getCiudad();
                    delegacion = deleg;
                }
            }
        }
        
        if(numero == 0 || miContribuyente.getIdContrib() == 0){
            JOptionPane.showMessageDialog(null, "Por favor, revise los valores");
            numero = 0;
            nombre = "ERROR";
            ciudad = "ERROR";
            
            jButton3.setEnabled(false);
        }
        matriz[0][0] = String.valueOf(miContribuyente.getIdContrib());
        matriz[0][1] = miContribuyente.getTipoCategoria();
        matriz[0][2] = String.valueOf(numero);
        matriz[0][3] = nombre;
        matriz[0][4] = ciudad;
        
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
           matriz,
            new String [] {
                "ID CONTRIB", "TIPO", "DNI/CUIT", "NOMBRE", "DELEGACION"
            }
        ));
        
        jButton3.setEnabled(true);
        
    }
    
    
    private JFrame getFrame(){
            return this;
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField2 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("EXIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("DNI / CUIT CONTRIBUYENTE");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton2.setText("BUSCAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "ID CONTRIBUYENTE", "TIPO CATEGORIA", "DNI / CUIT", "NOMBRE", "DELEGACION"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setText("ID CONTRIBUYENTE");

        jLabel3.setText("TIPO");

        jButton3.setText("MODIFICAR");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton1))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 652, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                    .addComponent(jTextField1))
                .addGap(38, 38, 38)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(260, 260, 260)
                .addComponent(jButton3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        String dni,id_contrib, tipo;
        dni = jTextField1.getText();
        id_contrib = jTextField2.getText();
        tipo = jComboBox1.getSelectedItem().toString();
        int numero = 0;
        int id_contribuyente = 0;
        
        if(!(dni.equals(""))){
           numero = Integer.parseInt(dni); 
        }
        if(!(id_contrib.equals(""))){
            id_contribuyente = Integer.parseInt(id_contrib);
        }
        
        if(((numero != 0) || (id_contribuyente != 0) ) && !(tipo.equals(""))){
            miContribuyente = miControlador.buscarContribuyente(numero, tipo, id_contribuyente);
            cargarTabla(numero, tipo);
        }else{
            JOptionPane.showMessageDialog(null, "Por favor, revisar los valores ingresados");
        }
        
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        ModificarContribuyente ventana1 = new ModificarContribuyente(miControlador, miContribuyente, fisico, 
                                                                                            juridico, delegacion){
            //Con esto cuando llamemos a dispose de vNueva abrimos la principal
            @Override
            public void dispose(){
                //Hacemos visible la principal
                getFrame().setVisible(true);
                //Cerramos vNueva
                super.dispose();
            }
        };
        ventana1.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
