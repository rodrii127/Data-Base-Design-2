package vista;

import controlador.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import java.sql.ResultSet;

public class ConsultarMoroso extends javax.swing.JFrame {

    private probando p;
    private Connection c = null;
    private Statement stmt = null;
    private Statement stmt2 = null;

    public ConsultarMoroso(probando pr) {
        initComponents();
        setVisible(true);
        setLocationRelativeTo(null);
        this.p = pr;
    }

    public void cargarTablas() {

        int ind = 0;

        try {
            this.iniciarConexion();
            stmt = c.createStatement();
            stmt2 = c.createStatement();

            ResultSet rs = stmt.executeQuery("select contribuyente.id_contrib as contribu, "
                    + "sum(impuesto.monto_impue) as tot "
                    + "from contribuyente inner join impuesto on contribuyente.id_contrib = impuesto.id_contrib "
                    + "where contribuyente.id_contrib in (select id_contrib from juridico) AND "
                    + "(fecha_pago > fecha_venci) group by contribuyente.id_contrib "
                    + "order by sum(impuesto.monto_impue) desc;");

            
            ResultSet rs2 = stmt2.executeQuery("select contribuyente.id_contrib as contribuy, "
                    + "sum(impuesto.monto_impue) as total "
                    + "from contribuyente inner join impuesto on contribuyente.id_contrib = impuesto.id_contrib "
                    + "where contribuyente.id_contrib in (select id_contrib from fisico) AND "
                    + "(fecha_pago > fecha_venci) group by contribuyente.id_contrib "
                    + "order by sum(impuesto.monto_impue) desc;");
            
            String[][] matrizJuridico = new String[20][2];

            while (rs.next()) {
                int contribuyente1 = Integer.parseInt(rs.getString("contribu"));
                float total1 = Float.parseFloat(rs.getString("tot"));
                matrizJuridico[ind][0] = String.valueOf(contribuyente1);
                matrizJuridico[ind][1] = String.valueOf(total1);
                ind++;
            }
            
            ind=0;
            
            String[][] matrizFisico = new String[20][2];
            
            while (rs2.next()) {
                int contribuyente2 = Integer.parseInt(rs2.getString("contribuy"));
                float total2 = Float.parseFloat(rs2.getString("total"));
                matrizFisico[ind][0] = String.valueOf(contribuyente2);
                matrizFisico[ind][1] = String.valueOf(total2);
                ind++;
            }
            
            rs.close();
            rs2.close();
            stmt.close();
            stmt2.close();
            c.close();

            jTable1.setModel(new javax.swing.table.DefaultTableModel(
                    matrizJuridico,
                    new String[]{
                        "CONTRIB", "TOTAL"
                    }
            ));
            
            jTable2.setModel(new javax.swing.table.DefaultTableModel(
                    matrizFisico,
                    new String[]{
                        "CONTRIB", "TOTAL"
                    }
            ));

        } catch (Exception e) {
            System.err.println(e);
            System.exit(0);
        }

    }
    
    public void iniciarConexion() {
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection("jdbc:postgresql://localhost:5432/tpfinal",
                            "rodrigo", "1234");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Opened database successfully");
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("Listar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Title 1", "Title 2"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jLabel2.setText("Personas Jurídicas");

        jLabel3.setText("Personas Físicas");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel2))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(154, 154, 154)
                        .addComponent(jButton1))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1)))
                .addGap(2, 2, 2)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(34, 34, 34)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
            this.cargarTablas();
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables
}
