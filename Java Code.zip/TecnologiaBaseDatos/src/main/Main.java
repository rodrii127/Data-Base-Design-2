package main;

import controlador.ControladorDePersistencia;
import clases.*;
import controlador.ControladorPrincipal;
import controlador.probando;
import java.util.*;
import vista.*;

public class Main {

    public static void main(String[] args) {
        //trabajar a nivel de base de datos
        ControladorDePersistencia persis = new ControladorDePersistencia();
        ControladorPrincipal miControlador = new ControladorPrincipal(persis);
        
        Login miLogin = new Login(miControlador);    
        
    }
    
}
